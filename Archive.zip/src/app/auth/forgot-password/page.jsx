import ForgotPssword from "@/components/Auth/forgot-password/ForgotPssword";
import React from "react";

const page = () => {
  return (
    <div>
      <ForgotPssword />
    </div>
  );
};

export default page;
