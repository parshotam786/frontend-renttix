import ResetPassword from "@/components/Auth/reset-password/ResetPassword";
import React from "react";

const page = () => {
  return (
    <div>
      <ResetPassword />
    </div>
  );
};

export default page;
