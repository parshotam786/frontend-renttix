export type dataStats = {
  icon?: string;
  color?: string;
  title?: string;
  value?: string;
  growthRate?: number;
  percent?: number;
};
