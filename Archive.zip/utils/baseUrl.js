export const BaseURL = process.env.NEXT_PUBLIC_API_URL;
export const imageBaseURL = process.env.NEXT_PUBLIC_API_URL_IMAGE;
